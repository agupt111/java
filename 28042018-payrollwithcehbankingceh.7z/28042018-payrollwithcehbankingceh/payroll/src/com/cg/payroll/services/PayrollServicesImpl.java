package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.daoservices.PayrollDAOServices;
public class PayrollServicesImpl implements PayrollServices{

	PayrollDAOServices daoServices = new PayrollDAOServicesImpl();
	public PayrollServicesImpl() {

	}

	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#acceptAssociateDetails(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, int, int, int, int, java.lang.String, java.lang.String)
	 */
	@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber
			,String bankName, String ifscCode) throws PayrollServicesDownException{
		/*Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
			daoServices.insertAssociate(associate);
				return associate.getAssociateID();*/
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#calculateNetSalary(int)
	 */
	@Override
	public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException,PayrollServicesDownException {
		Associate associate=this.getAssociateDetails(associateID);
		double taxAmount=0.0;
		if(associate!=null){
			associate.getSalary().setPersonalAllowance((int)(30*associate.getSalary().getBasicSalary())/100);
			associate.getSalary().setConveyenceAllowance((int)(20*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setOtherAllowance((int)(10*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setHra((int)(2.5*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setGratuity((int)(50*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setGrossSalary(associate.getSalary().getPersonalAllowance()+associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			double annualSalary=associate.getSalary().getGrossSalary()*12;
			double taxableSalary=annualSalary;
			double nonTaxableSalary=associate.getYearlyInvestmentUnder80C()+(associate.getSalary().getEpf()*12)+(associate.getSalary().getCompanyPf()*12);
			if(nonTaxableSalary>150000)
				nonTaxableSalary=150000;
			if(taxableSalary<=250000){
				taxAmount=0;
			}	
			else if(taxableSalary>250000 && taxableSalary<=500000){
				taxableSalary=taxableSalary-250000-nonTaxableSalary;
				if(taxableSalary<0)
					taxAmount=0;
				else
				taxAmount=taxableSalary*0.1;	
			}
			else if (taxableSalary>500000 && taxableSalary<=1000000){
				double taxSlab2=(500000-250000-nonTaxableSalary)*0.1;
				taxAmount=(taxableSalary-500000)*0.2+taxSlab2;	
			}
			else if (taxableSalary>1000000){
				double taxSlab2=(500000-250000-nonTaxableSalary)*0.1;
				double taxSlab3=(500000)*0.2;
				taxAmount=(taxableSalary-1000000)*0.3+taxSlab3+taxSlab2;	
			}
			associate.getSalary().setMonthlyTax((int)taxAmount/12);
			associate.getSalary().setNetSalary((int)((annualSalary-taxAmount)/12)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
			return  associate.getSalary().getNetSalary();
		}
		return 0;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*Associate associate=this.getAssociateDetails(associateID);
		if(associate!=null) {
			associate.getSalary().setPersonalAllowance((int)((0.3)*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setConveyenceAllowance((int)(0.2*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setOtherAllowance((int)(0.1*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setHra((int)(0.25*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setGratuity((int)(0.05*(associate.getSalary().getBasicSalary())));
			int totalAllowances = associate.getSalary().getPersonalAllowance()
					+associate.getSalary().getConveyenceAllowance()
					+associate.getSalary().getHra()
					+associate.getSalary().getOtherAllowance();
			int monthlyGrossSalary = associate.getSalary().getBasicSalary()
					+totalAllowances
					+associate.getSalary().getCompanyPf();
			associate.getSalary().setGrossSalary(monthlyGrossSalary);
			int annualGrossSalary = monthlyGrossSalary*12;

			int annualEpf = associate.getSalary().getEpf()*12;

			int annualCompanypf = associate.getSalary().getCompanyPf()*12;
			/*int i,j,tax;
			if((associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf())>=150000) {
				j=1500000;
			}
			else
				j=associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf();
		   if(annualGrossSalary<250000) {
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
		   }
		   else if(annualGrossSalary>=250000&&annualGrossSalary<500000) {
			   i=(annualGrossSalary-250000-j);
			   if(i<0)
				   tax=0;
			   tax=(int)(0.1*i)/12;
			   associate.getSalary().setMonthlyTax((int)(tax=(int)(0.1*i)/12));
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
		   }
		   else if(annualGrossSalary>=500000&&annualGrossSalary<100000) {
			   i=(int)((250000-j)*0.1);
			   tax=(int)(((annualGrossSalary-500000)*0.2)+i)/12;
			   associate.getSalary().setMonthlyTax((int)(((annualGrossSalary-500000)*0.2)+i)/12);
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax);
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax); 
		   }
		   else if(annualGrossSalary>100000) {
			   i=(int)((2500000-j)*0.1);
			   tax=(int)((i+100000+((annualGrossSalary-1000000)*0.3))/12);
			   associate.getSalary().setMonthlyTax((int)((i+100000+((annualGrossSalary-1000000)*0.3))/12));
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax);
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax); 

		   }*/



			/*int yearly80C= associate.getYearlyInvestmentUnder80C()-annualEpf-annualCompanypf;

			int taxableAmount = annualGrossSalary-yearly80C;

			int annualTax=0;

			if(taxableAmount>0) {
				if(taxableAmount<250000)
					annualTax=(int)(0.1*taxableAmount);
				if((taxableAmount>=250000)&&(taxableAmount>500000))
					annualTax=25000+(int)(0.2*(taxableAmount-250000));
				if(taxableAmount>=500000)
					annualTax=25000+100000+(int)(0.3*(taxableAmount-750000));	
			}
			//int monthlyTax=annualTax/12;
			associate.getSalary().setMonthlyTax(annualTax/12);
			/*int monthlyNetSalary= monthlyGrossSalary-associate.getSalary().getMonthlyTax()
							-associate.getSalary().getEpf()
							-associate.getSalary().getCompanyPf();*/

			/*associate.getSalary().setNetSalary( monthlyGrossSalary-associate.getSalary().getMonthlyTax()
					-associate.getSalary().getEpf()
					-associate.getSalary().getCompanyPf());






		}		

		return 0;*/
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails(int)
	 */
	@Override
	public Associate getAssociateDetails(int associateID)  throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		Associate associate =daoServices.getAssociate(associateID);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate details of  "+associateID+" not found");
		return associate;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAllAssociatesDetails()
	 */
	@Override
	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		return daoServices.getAssociates();
	}

	@Override
	public boolean updateAssociateDetails(Associate associate) throws AssociateDetailsNotFoundException,PayrollServicesDownException {
		return daoServices.updateAssociate(associate);
	}

	

}
