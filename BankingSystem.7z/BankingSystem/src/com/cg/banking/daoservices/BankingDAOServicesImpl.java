package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

public class BankingDAOServicesImpl implements BankingDAOServices {
	public static HashMap<Integer,Customer> customers= new HashMap<>();
//	private static int CUSTOMER_ID_COUNTER=111;
//	private static int CUSTOMER_IDX_COUNTER=0;
//	private static long ACCOUNT_ID_COUNTER=1;	
	private static int PINNUMBER=1000;
	private static Random random=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		System.out.println(2);
		customers.put(BankingUtility.CUSTOMER_ID_COUNTER,customer);
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_ID_COUNTER, account);
		customers.get(customerId).getAccounts().get(BankingUtility.ACCOUNT_ID_COUNTER).setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		return account.getAccountNo();
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		if(customers.containsKey(customerId)==true) {
			if(customers.get(customerId).getAccounts().containsKey(account.getAccountNo())==true) {
				customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_ID_COUNTER, account);
				customers.get(customerId).getAccounts().get(account.getAccountNo()).setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
				return true;
			}
		}
		return false;
	}

	@Override
	public float balanceEnquiry(int customerId,long accountNo,int pinNumber) {
		if(customers.get(customerId).getAccounts().get(accountNo).getPinNumber()==pinNumber) {
			return this.getAccount(customerId, accountNo).getAccountBalance();
		}
		return 0;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		getCustomer(customerId).getAccounts().get(account.getAccountNo()).setPinNumber(random.nextInt(10000));
		return account.getPinNumber();
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo)==null)
			return false;

		customers.get(customerId).getAccounts().get(accountNo).getTransactions().put(getAccount(customerId, accountNo).getTRANSACTION_ID_COUNTER(),transaction);
		customers.get(customerId).getAccounts().get(accountNo).getTransactions().get(getAccount(customerId, accountNo).getTRANSACTION_ID_COUNTER()).setTransactionId(getAccount(customerId, accountNo).getTRANSACTION_ID_COUNTER()+1);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {

		customers.get(customerId).getAccounts().remove(accountNo);
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		Account a=customers.get(customerId).getAccounts().get(accountNo);
		if(a==null)
			return null;
		return a;
	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<>(customers.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {

		return new ArrayList<>(getCustomer(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());
	}
}
