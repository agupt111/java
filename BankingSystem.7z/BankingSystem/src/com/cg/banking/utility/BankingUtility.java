package com.cg.banking.utility;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=111;
	public static int CUSTOMER_IDX_COUNTER=0;
	public static long ACCOUNT_ID_COUNTER=1;
	public static int TRANSACTION_ID_COUNTER=1;
	public static String ACCOUNT_STATUS_ACTIVE;
	public static String ACCOUNT_STATUS_BLOCKED;
	public static long ACCOUNT_NO_COUNTER;
	public int TRANSACTION_IDX_COUNTER=0;
}
